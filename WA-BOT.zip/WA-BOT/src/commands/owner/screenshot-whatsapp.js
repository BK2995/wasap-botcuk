export default {
    name: 'sswa',
    aliases: ['listchat', 'listmsg'],
    type: 'owner',
    desc: "Screenshot homepage whatsapp web",
    execute: async({ mrbkeybot, m }) => {
        await mrbkeybot.mPage.setViewportSize({ width:961, height: 2000 })
        let media = await mrbkeybot.mPage.screenshot()
        await mrbkeybot.sendMessage(m.from, media, { quoted: m })
    },
    isOwner: true
}
