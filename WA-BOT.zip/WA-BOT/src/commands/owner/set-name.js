export default {
    name: 'setname',
    type: 'owner',
    desc: 'change name bot',
    example: 'Ghost?\n\nExample : %prefix%command Mr. BKeyBot',
    execute: async({ m }) => {
        let text = m.hasQuotedMsg && !m.text ? m.quoted.body : m.text
        await mrbkeybot.setDisplayName(text)
    },
    isOwner: true
}