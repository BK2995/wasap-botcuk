export default {
    name: 'setprofile',
    aliases: ['setpp'],
    type: 'owner',
    desc: 'change profile pic number bot, for long profile %prefix%command <reply image>',
    execute: async({ mrbkeybot, m, quoted }) => {
        let media = await quoted.downloadMedia()
        if (m.text.toLowerCase().endsWith('long')) {
            await mrbkeybot.setProfilePic(mrbkeybot.info.wid._serialized, media, 'long')
        } else {
            await mrbkeybot.setProfilePic(mrbkeybot.info.wid._serialized, media)
        }
    },
    isOwner: true,
    isMedia: {
        Image: true
    }
}