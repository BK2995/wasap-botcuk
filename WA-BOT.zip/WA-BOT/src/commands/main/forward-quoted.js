export default {
    name: 'quoted',
    aliases: ['q', 'get-quoted', 'getquoted'],
    type: 'main',
    desc: 'get quoted message',
    execute: async({ mrbkeybot, m }) => {
        let message = await mrbkeybot.loadMessage(m.quoted._serialized)
        if (!message.quoted) {
            if (message.id.remote === 'status@broadcast') {
                if (message.isMedia) {
                    let download = await mrbkeybot.downloadMediaMessage(message)
                    return mrbkeybot.sendMessage(m.from, download, { caption: message.body.length < 200 ? message.body : '' })
                } else {
                    return m.reply(message.body)
                }
            } else {
                return mrbkeybot.forwardMessage(message.from, message._serialized)
            }
        }
        await mrbkeybot.forwardMessage(message.quoted?.from, message.quoted?._serialized)
    },
    isQuoted: true
}